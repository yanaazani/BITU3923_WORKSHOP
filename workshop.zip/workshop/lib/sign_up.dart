import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:fluttertoast/fluttertoast.dart';


class Patient {
  int patientId = 0;
  String email = "";
  String ic = "";
  String name = "";
  String phone = "";
  String password = "";
  double height = 0.0;
  String gender = "";
  double weight = 0.0;

  Patient(this.patientId, this.email, this.ic, this.name,
      this.phone, this.password, this.gender, this.height, this.weight);

  Patient.fromJson(Map<String, dynamic> json) {
    patientId = json["id"];
    email = json["email"];
    name = json["name"];
    ic = json["ic"];
    phone = json["phone"];
    password = json["password"];
    gender = json["gender"];
    height = json["height"];
    weight = json["weight"];
  }

  int get _Id => patientId;
  set _Id(int value) => patientId = value;

  String get _ic => ic;
  set _ic(String value) => ic = value;


  String get _name => name;
  set _name(String value) => name = value;

  String get _Email => email;
  set _Email(String value) => email = value;

  String get _password => password;
  set _password(String value) => password = value;

  String get _phone => phone;
  set _phone(String value) => phone = value;

  double get _weight => weight;
  set _weight(double value) => weight = value;

  double get _height => height;
  set _height(double value) => height = value;

  String get _gender => gender;
  set _gender(String value) => gender = value;
}

class SignupPage extends StatelessWidget {

  // Each 1 textfield must have 1 TextEdittingController() !
  TextEditingController emailEdittingController = TextEditingController();
  TextEditingController icEdittingController = TextEditingController();
  TextEditingController nameEdittingController = TextEditingController();
  TextEditingController phoneEdittingController = TextEditingController();
  TextEditingController passwordEdittingController = TextEditingController();
  TextEditingController heightEdittingController = TextEditingController();
  TextEditingController weightEdittingController = TextEditingController();
  TextEditingController genderEdittingController = TextEditingController();

  String url = "http://10.0.3.2:8080/pkums/patient/signup";

  Patient patient = Patient(0, "", "", "", "", "", "", 0.0, 0.0);


  Future register() async{
    var response = await http.post(Uri.parse(url),
        headers: {'Content-Type': 'application/json'},
        body: json.encode(
            {
              "email": emailEdittingController.text,
              "password": passwordEdittingController.text,
              "ic": icEdittingController.text,
              "phone": phoneEdittingController.text,
              "name": nameEdittingController.text,
              "height": heightEdittingController.text,
              "weight": weightEdittingController.text,
              "gender": genderEdittingController.text,
            }
        )
    );

    if(response.body != null){

      Fluttertoast.showToast(
        msg: "Successful registered! You will be redirected to login",
        backgroundColor: Colors.white,
        textColor: Colors.red,
        toastLength: Toast.LENGTH_LONG,
        fontSize: 16.0,
      );

      /*Future.delayed(Duration(seconds: 5), () {
        Navigator.of(context).push(
          MaterialPageRoute(builder: (context) => Login()),
        );
      });*/

    }

  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(backgroundColor: Colors.white,),
      body: Center(
          child: SingleChildScrollView(
            child: Column(
              children: [
                Text("Sign Up",
                  style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 40,
                      color:Colors.black),),
                const SizedBox(height: 10),
                Text(
                  "Create your account",
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
                Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: TextFormField(
                    decoration: InputDecoration(
                        enabledBorder: OutlineInputBorder(
                          borderSide: const BorderSide(
                              width: 2, color: Colors.black54),
                          borderRadius: BorderRadius.circular(50.0),
                        ),
                        prefixIcon: const Icon(Icons.person_outline),
                        filled: true,
                        fillColor: Colors.white70,
                        hintText: "Enter your name"),
                    controller: nameEdittingController,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: TextFormField(
                    decoration: InputDecoration(
                        enabledBorder: OutlineInputBorder(
                          borderSide: const BorderSide(
                              width: 2, color: Colors.black54),
                          borderRadius: BorderRadius.circular(50.0),

                        ),
                        prefixIcon: const Icon(Icons.perm_identity),
                        filled: true,
                        fillColor: Colors.white70,
                        hintText: "Enter your ic"),
                    controller: icEdittingController,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: TextFormField(
                    decoration: InputDecoration(
                        enabledBorder: OutlineInputBorder(
                          borderSide: const BorderSide(
                              width: 2, color: Colors.black54),
                          borderRadius: BorderRadius.circular(50.0),

                        ),
                        prefixIcon: const Icon(Icons.email),
                        filled: true,
                        fillColor: Colors.white70,
                        hintText: "Enter your email"),
                    controller: emailEdittingController,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: TextFormField(
                    decoration: InputDecoration(
                        enabledBorder: OutlineInputBorder(
                          borderSide: const BorderSide(
                              width: 2, color: Colors.black54),
                          borderRadius: BorderRadius.circular(50.0),

                        ),
                        prefixIcon: const Icon(Icons.phone),
                        filled: true,
                        fillColor: Colors.white70,
                        hintText: "Enter your phone"),
                    controller: phoneEdittingController,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: TextFormField(
                    decoration: InputDecoration(
                        enabledBorder: OutlineInputBorder(
                          borderSide: const BorderSide(
                              width: 2, color: Colors.black54),
                          borderRadius: BorderRadius.circular(50.0),
                        ),
                        prefixIcon: const Icon(Icons.lock),
                        filled: true,
                        fillColor: Colors.white70,
                        hintText: "Enter your password"),
                    controller: passwordEdittingController,
                  ),
                ),

                  Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                  ElevatedButton(
                  style: ButtonStyle(
                  foregroundColor: MaterialStateProperty.all(Colors.black),
                  backgroundColor: MaterialStateProperty.all(Colors.deepPurple[100]),
                ),
                  onPressed: () {
                    register();
                  }, child: const Text("Register")),
              ],
            ),
      ],
    ),
          ),
      ),
    );
  }
}




