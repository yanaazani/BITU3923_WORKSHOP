import 'package:flutter/material.dart';
import 'package:ui/profile.dart';

import 'appointment.dart';

class MenuPage extends StatefulWidget {
  const MenuPage({super.key});

  @override
  State<MenuPage> createState() => _MenuPageState();
}

class _MenuPageState extends State<MenuPage> {

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(backgroundColor: Colors.white,
          title:
          Text("Home", style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 40,
            color: Colors.black,
          ),
          ),
        ),
        body: MyGridView(),
      ),
    );

  }
}
class MyGridView extends StatelessWidget {
  get onPressed => null;
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.fromLTRB(10, 10, 20, 200),
      color: Colors.deepPurple[100],
      child: GridView.count(
        primary: false,
        padding: const EdgeInsets.all(20),
        crossAxisSpacing: 2,
        mainAxisSpacing: 5,
        crossAxisCount: 2,
        children: <Widget>[
          Container(
            padding: EdgeInsets.all(20),
            child: Column(
              children: [
                Text("Appointment", style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold,),),
                IconButton.filledTonal(icon: const Icon(Icons.local_hospital), iconSize: 40,
                  onPressed: (){
                    Navigator.push(context, MaterialPageRoute(builder: (context)=>AppointmentPage()),);
                  },),
              ],
            ),
          ),
          Container(
            padding: EdgeInsets.all(20),
            child: Column(
              children: [
                Text("Date", style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold,),),
                IconButton.filledTonal(
                    iconSize: 40,
                    onPressed: onPressed,
                    icon: const Icon(Icons.calendar_month)),
              ],
            ),
          ),
          Container(
            padding: EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.deepPurple[100],
            ),
            child: Column(
              children: [
                Text("Feedback", style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold,),),
                IconButton.filledTonal(
                    iconSize: 40,
                    onPressed: onPressed,
                    icon: const Icon(Icons.feedback_rounded)),
              ],
            ),
          ),
          Container(
            padding: EdgeInsets.all(20),
            child: Column(
              children: [
                Text("Profile", style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold,),),
                IconButton.filledTonal(
                    iconSize: 40,
                    onPressed: (){
                      Navigator.push(context, MaterialPageRoute(builder: (context)=>ProfilePage()),);
                    },
                    icon: const Icon(Icons.people)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

